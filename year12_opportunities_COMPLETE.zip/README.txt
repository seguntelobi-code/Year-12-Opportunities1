YEAR 12 OPPORTUNITIES HUB — COMPLETE GOOGLE SHEET VERSION

1. Upload index.html directly into the ROOT of your GitHub repository.
2. Import opportunities_template.csv into Google Sheets.
3. In Google Sheets choose File → Share → Publish to web.
4. Publish the opportunities sheet as CSV.
5. Copy the published CSV URL.
6. In index.html find:
   const GOOGLE_SHEET_CSV_URL="";
   Paste your CSV URL between the quotation marks.
7. Upload the updated index.html to GitHub Pages.

After that, edit the Google Sheet whenever you have a new opportunity. The QR code
can keep pointing to the same website.

Columns:
section | area | title | organisation | deadline | description | link

Use dates such as 2026-10-15 for deadline so the website can label upcoming deadlines.

The site includes search, section filters, deadline filters, and career-area filters.
Work Experience areas include Finance & Business; Law, Government & Public Service;
Medicine & Health; Science, Technology & Engineering; Construction, Property & Skilled
Trades; Education, Childcare & Social Care; Retail, Hospitality & Customer Service;
Creative, Media & Communications; Sport, Fitness & Leisure; Environment, Animals &
Agriculture; and Public Safety & Emergency Services.

Only publish public opportunity information. Never put student names, emails,
application details, passwords or other private information in the public Sheet.
